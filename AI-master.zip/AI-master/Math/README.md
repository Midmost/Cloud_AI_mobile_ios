# AI를 위한 기초 수학관련 콘텐츠 모음
기초가 약한 분들은 자존심을 버리고 아래 콘텐츠 부터 보세요. 

## 방정식
[초등 수학 개념잡기 -45강 방정식 #1](https://youtu.be/0ARRazo2ssk)<br>
[초등 수학 개념잡기 -45강 방정식 #2](https://youtu.be/qM4_EmBbA2g)<br>
[초등 수학 개념잡기 -45강 방정식 #3](https://youtu.be/0O4Gkte7YVo)<br>
[초등 수학 개념잡기 -45강 방정식 #4](https://youtu.be/534eclpoA8s)<br>
[중1예비과정 수학 일차방정식](https://youtu.be/Nkp2fFR9Zig)<br>
[중1예비과정 수학 일차방정식의 활용](https://youtu.be/tsNXL-BUGqY)<br>

## 약분과 통분
[초등 수학 개념잡기 -26강 약분과 통분 #1](https://youtu.be/JO7qzBPrIHk)<br>
[초등 수학 개념잡기 -26강 약분과 통분 #2](https://youtu.be/hGumHOGI1t8)<br>
[초등 수학 개념잡기 -26강 약분과 통분 #3](https://youtu.be/Tu8n4GehcqI)<br>
[초등 수학 개념잡기 -26강 약분과 통분 #4](https://youtu.be/D7X1PZw7qj8)<br>