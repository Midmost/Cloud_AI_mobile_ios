# Sung Kim 교수님 강좌
[Sung Kim's website](http://hunkim.github.io/ml/)<br>

# 김성범 교수님 강좌 
전체 강좌 목록 
[https://www.youtube.com/channel/UCueLU1pCvFlM8Y8sth7a6RQ/videos](https://www.youtube.com/channel/UCueLU1pCvFlM8Y8sth7a6RQ/videos)<br>

[#01 머신러닝 및 인공지능 개요](https://www.youtube.com/watch?v=pFyFHUmxgu0)<br>
[#02 수치예측, 범주예측(분류)](https://youtu.be/FfUHRuUxQiY)<br>