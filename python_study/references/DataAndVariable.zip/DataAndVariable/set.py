#집합
set1 =  set([(1,2,3), 12, 'mom', b'papa',range(7)])
set2 = {
    (10,21,90), 'android', 
    'surface', 13, range(7, 15)
    }

set1, set2

type(set1), type(set2)

