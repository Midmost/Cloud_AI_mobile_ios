#Boolean 기본 값은 False
b = bool()
b

#정수형 - int만 제공
i = 10
i
type(i)

#실수형 - 단정도 및 배정도
d = 3.14
d
type(d)

#허수형 - 실수부와 허수부
c = complex(3+4j)
c
type(c)

