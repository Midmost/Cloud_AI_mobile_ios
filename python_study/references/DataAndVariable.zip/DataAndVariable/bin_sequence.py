#바이너리 시퀀스
b = bytes(b'hidden heros')
ba = bytearray(b'Microsoft MVP')
b, ba

type(b), type(ba)

