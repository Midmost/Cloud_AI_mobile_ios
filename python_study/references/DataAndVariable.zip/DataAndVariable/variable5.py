from sys import argv
script, first, second, third = argv

print("호출된 스크립트 이름:", script)
print("첫 번째 변수:", first)
print("두 번째 변수:", second)
print("세 번째 변수:", third)

#python variable5.py 변수1 변수2 변수3
#python variable5.py 수박 황도 키위

