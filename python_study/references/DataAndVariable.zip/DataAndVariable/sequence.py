#리스트
seq_list = [7, 'i', 3.1, [42, 89], complex(3-1j)]
seq_list
type(seq_list)

#튜플
t1 = 11,21,31,41
t2 = (42,24,167,313)
t1,t2
type(t1), type(t2)

#범위
r = range(10)
print(r, type(r)) 
li =  list(r)
print(li,type(li))

