#텍스트 시퀀스 - 문자열
single_str = 'Microsoft MVP'
triple_str = """
Microsoft Most Valuable Professionals, or MVPs, are technology experts who passionately share their knowledge with the community. 
They are always on the "bleeding edge" and have an unstoppable urge to get their hands on new, exciting technologies.
"""
single_str, triple_str
type(single_str), type(triple_str)

