#매핑 - 딕셔너리
dict =  {'name':'steelflea', 'age':30}
dict['job'] = 'writer'
dict.update({(0,1):22})
dict

type(dict)

