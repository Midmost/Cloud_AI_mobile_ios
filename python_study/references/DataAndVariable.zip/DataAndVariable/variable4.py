age = input("몇 살이죠? ")
height = input("키는 얼마죠? ")
weight = input("몸무게는 얼마죠? ")

print(f"당신은 {age}살이고, 키는 {height}, 몸무게는 {weight}입니다.")


