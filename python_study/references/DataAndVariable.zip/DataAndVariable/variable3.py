print("몇 살이죠?", end=' ')
age = input()
print("키가 얼마죠?", end=' ')
height = input()
print("몸무게는 얼마죠?", end=' ')
weight = input()

print(f"당신은 {age}살이고, 키는 {height}, 몸무게는 {weight}네요.")

