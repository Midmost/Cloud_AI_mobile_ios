from song_class import Song

happy_bday = Song(["생일 축하 합니다.",
                   "사랑하는 귀도 반 로썸",
                   "생일 억수로 축하 합니다."])

bulls_on_parade = Song(["조개껍질 묶어",
                        "그녀의 목에 걸고"])

happy_bday.sing_a_song()

bulls_on_parade.sing_a_song()

