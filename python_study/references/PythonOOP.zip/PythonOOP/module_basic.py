import fruit

fruit.get_apple()
print(fruit.fruit)

