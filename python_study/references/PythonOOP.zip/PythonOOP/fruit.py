def get_apple():
    print("사과 한 상자를 배송했습니다.")

fruit ="난 망고가 좋은데..."


